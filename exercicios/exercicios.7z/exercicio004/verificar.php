<?php
$idade = $_POST['idade'];

if($idade>18){
    echo "Você tem mais de 18 anos";
}else if($idade < 18){
    echo "Você tem menos de 18 anos";
}else{
    echo "Você tem 18 anos";
}
?>