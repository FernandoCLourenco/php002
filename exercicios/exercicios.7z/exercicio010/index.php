<?php
$idade = 19;

if($idade>= 18){
    echo "Você é maior de idade";
}else{
    echo "Você é menor de idade";
}
?>
