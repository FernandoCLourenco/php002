<?php
    $num == 0;
    while($num<99){
    $num = $num + 1;
    if($num % 2 != 0){
    echo "$num <br>";
    }
    }
    ?>