<?php
$nome = "Maria";

echo "Olá $nome";
?>