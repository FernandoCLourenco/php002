<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabuada mt poggers</title>
</head>
<body>
    <form name="formulario" method="post" action="tabueiro.php">
        Idade: <input type="text" name="tabuada"><br>
        <button type="submit">"Tabuar"</button>
    </form>
</body>
</html>