<?php
    $num == 0;
    while($num<10){
    $num = $num + 1;
    echo $num * 8 . "<br>";
    }
    ?>