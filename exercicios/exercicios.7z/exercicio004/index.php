<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Idade</title>
</head>
<body>
    <form name="formulario" method="post" action="verificar.php">
        Idade: <input type="text" name="idade"><br>
        <button type="submit">Verificar Idade</button>
    </form>
</body>
</html>